/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.BookFacadeLocal;
import za.ac.tut.entities.Author;
import za.ac.tut.entities.Book;

/**
 *
 * @author pulel
 */
public class AddBookServlet extends HttpServlet {

    @EJB
    private BookFacadeLocal bfl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Long isbn = Long.parseLong(request.getParameter("isbn"));
            String title = request.getParameter("title");
            Double price = Double.parseDouble(request.getParameter("price"));
            String pubDate = request.getParameter("publicatonDate");
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
            Date publicatonDate = dateFormat.parse(pubDate);
            String authorName = request.getParameter("authorName");
            String authorSurname = request.getParameter("authorSurname");
            
            Book book = creatBook(isbn,title,price,publicatonDate,authorName,authorSurname);
            bfl.create(book);
            
            request.getRequestDispatcher("add_book_outcome.jsp").forward(request, response);
            
        } catch (ParseException ex) {
            Logger.getLogger(AddBookServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private Book creatBook(Long isbn, String title, Double price, Date publicatonDate, String authorName, String authorSurname) {
       Book book = new Book();
       Author author = new Author();
       
       author.setName(authorName);
       author.setSurname(authorSurname);
       
       book.setId(isbn);
       book.setTitle(title);
       book.setPrice(price);
       book.setPublicationDate(publicatonDate);
       book.setAuthor(author);
       book.setCreationDate(new Date());

        return book;

    }
}
